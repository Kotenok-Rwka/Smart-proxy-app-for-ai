package ru.smartproxy.core

/**
 * Точка подключения VPN-движка. НЕ РЕАЛИЗОВАНО в этой заготовке.
 * Нужно: VpnService + Xray-ядро (libv2ray.aar из AndroidLibXrayLite) + tun2socks (hev-socks5-tunnel),
 * ровно как сделано в v2rayNG. Проще всего перенести этот код из форка v2rayNG.
 */
interface Engine {
    fun start(xrayConfigJson: String)
    fun stop()
    val isRunning: Boolean
}

/** Заглушка, чтобы интерфейс можно было запустить и оценить без движка. */
class FakeEngine : Engine {
    override var isRunning = false
        private set
    override fun start(xrayConfigJson: String) { isRunning = true }
    override fun stop() { isRunning = false }
}
