package ru.smartproxy.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.smartproxy.core.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SmartProxyTheme { App() } }
    }
}

@Composable
fun App() {
    var tab by remember { mutableIntStateOf(0) }
    var connected by remember { mutableStateOf(false) }
    val engine = remember { FakeEngine() } // TODO: заменить реальным движком
    var settings by remember { mutableStateOf(AiDnsSettings()) }

    Column(Modifier.fillMaxSize().background(Pal.Ink).statusBarsPadding()) {
        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> HomeScreen(connected, settings) {
                    if (connected) engine.stop() else engine.start("{}")
                    connected = engine.isRunning
                }
                else -> AiScreen(settings) { settings = it }
            }
        }
        NavBar(tab) { tab = it }
    }
}

@Composable
fun HomeScreen(connected: Boolean, s: AiDnsSettings, onToggle: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(28.dp))
        Text(
            if (connected) "Подключено" else "Отключено",
            color = Pal.Text, fontSize = 30.sp, fontWeight = FontWeight.SemiBold,
        )
        Spacer(Modifier.height(6.dp))
        Text(
            if (connected) "ИИ идёт напрямую, остальное через VPN" else "Нажмите на узел, чтобы подключиться",
            color = Pal.Muted, fontSize = 15.sp,
        )
        Spacer(Modifier.height(18.dp))
        RouteHero(connected, onToggle)
        Spacer(Modifier.height(20.dp))
        LaneCard("Через VPN", "YouTube, соцсети и всё остальное", Pal.Vpn, "DNS сервера")
        Spacer(Modifier.height(12.dp))
        LaneCard("Напрямую", "${s.domains.size} доменов ИИ", Pal.Direct, s.dnsHost)
        Spacer(Modifier.height(24.dp))
    }
}

/** Главный элемент: узел-кнопка, из которого расходятся две дорожки. */
@Composable
fun RouteHero(connected: Boolean, onToggle: () -> Unit) {
    val flow by rememberInfiniteTransition(label = "flow").animateFloat(
        0f, 48f, infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "phase",
    )
    val glow by animateFloatAsState(if (connected) 1f else 0f, tween(450), label = "glow")

    Box(Modifier.fillMaxWidth().height(250.dp), contentAlignment = Alignment.CenterStart) {
        Canvas(Modifier.fillMaxSize()) {
            val start = Offset(size.width * 0.30f, size.height / 2)
            fun lane(endY: Float, color: Color) {
                val end = Offset(size.width * 0.97f, endY)
                val p = Path().apply {
                    moveTo(start.x, start.y)
                    cubicTo(start.x + 120f, start.y, end.x - 180f, endY, end.x, endY)
                }
                drawPath(p, color.copy(alpha = 0.22f), style = Stroke(7f, cap = StrokeCap.Round))
                if (glow > 0.01f) {
                    drawPath(
                        p, color.copy(alpha = glow),
                        style = Stroke(7f, cap = StrokeCap.Round, pathEffect = PathEffect.dashPathEffect(floatArrayOf(26f, 22f), -flow)),
                    )
                }
                drawCircle(color.copy(alpha = 0.35f + 0.65f * glow), 11f, end)
            }
            lane(size.height * 0.20f, Pal.Vpn)
            lane(size.height * 0.80f, Pal.Direct)
        }
        Box(
            Modifier.padding(start = 12.dp).size(108.dp).clip(CircleShape)
                .background(if (connected) Pal.PanelHi else Pal.Panel)
                .clickable(onClick = onToggle),
            contentAlignment = Alignment.Center,
        ) {
            Text(if (connected) "Стоп" else "Старт", color = if (connected) Pal.Direct else Pal.Text,
                fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun LaneCard(title: String, sub: String, accent: Color, trailing: String) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Pal.Panel).padding(18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.width(5.dp).height(40.dp).clip(RoundedCornerShape(3.dp)).background(accent))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Pal.Text, fontSize = 17.sp, fontWeight = FontWeight.Medium)
            Text(sub, color = Pal.Muted, fontSize = 14.sp)
        }
        Text(trailing, color = accent, fontSize = 13.sp)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AiScreen(s: AiDnsSettings, onChange: (AiDnsSettings) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp)) {
        Text("Правила для ИИ", color = Pal.Text, fontSize = 28.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        Text("Эти сайты резолвятся отдельным DNS и идут мимо VPN-сервера.", color = Pal.Muted, fontSize = 15.sp)
        Spacer(Modifier.height(22.dp))

        Text("DNS для ИИ", color = Pal.Direct, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = s.dnsUrl, onValueChange = { onChange(s.copy(dnsUrl = it)) },
            modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(16.dp),
            label = { Text("Адрес DoH") },
        )
        Spacer(Modifier.height(10.dp))
        Text("Запасные: dns.bezmezhau.com, dns.zapret.moe, free.shecan.ir. Автовыбор рабочего добавим после запуска движка.",
            color = Pal.Muted, fontSize = 13.sp)

        Spacer(Modifier.height(26.dp))
        Text("Домены (${s.domains.size})", color = Pal.Direct, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(10.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            s.domains.forEach { d ->
                Text(
                    d.removePrefix("domain:"), color = Pal.Text, fontSize = 13.sp,
                    modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(Pal.PanelHi)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                )
            }
        }
    }
}

@Composable
fun NavBar(selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Pal.Panel).navigationBarsPadding().padding(10.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        listOf("Подключение", "Правила ИИ").forEachIndexed { i, label ->
            val on = i == selected
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(16.dp))
                    .background(if (on) Pal.PanelHi else Color.Transparent)
                    .clickable { onSelect(i) }.padding(vertical = 14.dp),
                contentAlignment = Alignment.Center,
            ) { Text(label, color = if (on) Pal.Text else Pal.Muted, fontSize = 15.sp, fontWeight = FontWeight.Medium) }
        }
    }
}
