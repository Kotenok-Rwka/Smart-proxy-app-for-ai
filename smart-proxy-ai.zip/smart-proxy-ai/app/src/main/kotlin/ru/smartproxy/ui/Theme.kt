package ru.smartproxy.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** Две дорожки трафика: синяя — через VPN, мятная — напрямую (ИИ). Всё остальное приглушено. */
object Pal {
    val Ink = Color(0xFF0E1120)
    val Panel = Color(0xFF171B2F)
    val PanelHi = Color(0xFF1F2440)
    val Vpn = Color(0xFF7C9BFF)
    val Direct = Color(0xFF5BE6B6)
    val Text = Color(0xFFEAEDFA)
    val Muted = Color(0xFF8D93B3)
    val Warn = Color(0xFFFFB86B)
}

@Composable
fun SmartProxyTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Pal.Vpn, secondary = Pal.Direct, background = Pal.Ink,
            surface = Pal.Panel, onBackground = Pal.Text, onSurface = Pal.Text,
        ),
        content = content,
    )
}
