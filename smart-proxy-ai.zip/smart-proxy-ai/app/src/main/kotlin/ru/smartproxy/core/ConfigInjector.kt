package ru.smartproxy.core

import org.json.JSONArray
import org.json.JSONObject

/** Kotlin-версия tools/inject_ai_dns.py: та же логика, те же теги. */
data class AiDnsSettings(
    val dnsUrl: String = "https://eu.geohide.ru/dns-query",
    val dnsHost: String = "eu.geohide.ru",
    val dnsIps: List<String> = listOf("5.175.161.3", "5.175.161.40", "37.221.93.141"),
    val domains: List<String> = AiDomains.default,
)

object AiDomains {
    val default = listOf(
        "domain:openai.com", "domain:chatgpt.com", "domain:oaistatic.com", "domain:oaiusercontent.com",
        "domain:anthropic.com", "domain:claude.ai", "domain:claude.com",
        "domain:gemini.google.com", "domain:aistudio.google.com", "domain:generativelanguage.googleapis.com",
        "domain:copilot.microsoft.com", "domain:perplexity.ai", "domain:x.ai", "domain:grok.com",
        "domain:mistral.ai", "domain:huggingface.co", "domain:poe.com",
    )
}

object ConfigInjector {
    private const val AI_DNS_TAG = "ai-dns"
    private const val RULE_TAG = "ai-direct"

    fun inject(profileJson: String, s: AiDnsSettings): String {
        val cfg = JSONObject(profileJson)
        val domains = JSONArray(s.domains.map { if (':' in it) it else "domain:$it" })
        val directTag = ensureDirect(cfg)

        val dns = cfg.optJSONObject("dns") ?: JSONObject().also { cfg.put("dns", it) }
        val hosts = dns.optJSONObject("hosts") ?: JSONObject().also { dns.put("hosts", it) }
        hosts.put(s.dnsHost, JSONArray(s.dnsIps))
        val old = dns.optJSONArray("servers") ?: JSONArray()
        val servers = JSONArray()
        servers.put(
            JSONObject()
                .put("tag", AI_DNS_TAG)
                .put("address", s.dnsUrl.replaceFirst("https://", "https+local://"))
                .put("domains", domains)
                .put("skipFallback", true)
        )
        for (i in 0 until old.length()) {
            val o = old.get(i)
            if (!(o is JSONObject && o.optString("tag") == AI_DNS_TAG)) servers.put(o)
        }
        dns.put("servers", servers)

        val routing = cfg.optJSONObject("routing") ?: JSONObject().also { cfg.put("routing", it) }
        val oldRules = routing.optJSONArray("rules") ?: JSONArray()
        val rules = JSONArray()
        rules.put(
            JSONObject().put("type", "field").put("ruleTag", RULE_TAG)
                .put("domain", domains).put("outboundTag", directTag)
        )
        for (i in 0 until oldRules.length()) {
            val r = oldRules.getJSONObject(i)
            if (r.optString("ruleTag") != RULE_TAG) rules.put(r)
        }
        routing.put("rules", rules)
        return cfg.toString(2)
    }

    private fun ensureDirect(cfg: JSONObject): String {
        val outs = cfg.optJSONArray("outbounds") ?: JSONArray().also { cfg.put("outbounds", it) }
        for (i in 0 until outs.length()) {
            val o = outs.getJSONObject(i)
            if (o.optString("protocol") == "freedom") {
                if (o.optString("tag").isEmpty()) o.put("tag", "direct")
                return o.getString("tag")
            }
        }
        outs.put(JSONObject().put("protocol", "freedom").put("tag", "direct").put("settings", JSONObject()))
        return "direct"
    }
}
