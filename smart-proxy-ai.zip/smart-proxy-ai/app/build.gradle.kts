plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "ru.smartproxy"
    compileSdk = 35
    defaultConfig {
        applicationId = "ru.smartproxy.ai"
        minSdk = 26; targetSdk = 35
        versionCode = 1; versionName = "0.1.0"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.15.0")
    // TODO(engine): libv2ray.aar (AndroidLibXrayLite) кладётся в app/libs и подключается так:
    // implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.aar"))))
}
