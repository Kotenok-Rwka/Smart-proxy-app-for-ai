#!/usr/bin/env python3
"""
Добавляет в Xray JSON-профиль (из подписки Happ/любой) правила для ИИ:
  - домены ИИ резолвятся через отдельный DNS (DoH/Smart DNS), запрос идёт НАПРЯМУЮ;
  - трафик к этим доменам выходит через outbound "direct" (мимо VPN-сервера);
  - всё остальное остаётся как в исходном профиле.

Использование:
  python3 inject_ai_dns.py profile.json > profile_ai.json
  python3 inject_ai_dns.py profile.json --dns https://eu.geohide.ru/dns-query \
      --dns-ip 5.175.161.3 --dns-ip 5.175.161.40 --domain claude.ai
"""
import argparse
import json
import sys

DEFAULT_DNS = "https://eu.geohide.ru/dns-query"
DEFAULT_DNS_HOST = "eu.geohide.ru"
DEFAULT_DNS_IPS = ["5.175.161.3", "5.175.161.40", "37.221.93.141"]

# Домены ИИ. Список дополняй под себя.
DEFAULT_AI_DOMAINS = [
    "domain:openai.com", "domain:chatgpt.com", "domain:oaistatic.com",
    "domain:oaiusercontent.com", "domain:sora.com",
    "domain:anthropic.com", "domain:claude.ai", "domain:claude.com",
    "domain:gemini.google.com", "domain:aistudio.google.com",
    "domain:generativelanguage.googleapis.com",
    "domain:bard.google.com", "domain:copilot.microsoft.com",
    "domain:perplexity.ai", "domain:x.ai", "domain:grok.com",
    "domain:mistral.ai", "domain:huggingface.co", "domain:poe.com",
]

AI_DNS_TAG = "ai-dns"
DIRECT_TAG = "direct"


def norm_domain(d: str) -> str:
    return d if ":" in d else f"domain:{d}"


def ensure_direct_outbound(cfg: dict) -> str:
    """Возвращает tag direct-outbound, создаёт при отсутствии."""
    outs = cfg.setdefault("outbounds", [])
    for o in outs:
        if o.get("protocol") == "freedom":
            if not o.get("tag"):
                o["tag"] = DIRECT_TAG
            return o["tag"]
    outs.append({"protocol": "freedom", "tag": DIRECT_TAG, "settings": {}})
    return DIRECT_TAG


def inject(cfg: dict, dns_url: str, dns_host: str, dns_ips: list, domains: list) -> dict:
    domains = [norm_domain(d) for d in domains]
    direct_tag = ensure_direct_outbound(cfg)

    # --- DNS ---
    dns = cfg.setdefault("dns", {})
    if isinstance(dns, dict):
        hosts = dns.setdefault("hosts", {})
        # bootstrap: имя DoH-сервера берём из жёстко заданных IP, без обращения к DNS
        hosts[dns_host] = dns_ips
        servers = dns.setdefault("servers", [])
        # https+local:// = DoH-запрос идёт напрямую, мимо прокси
        ai_server = {
            "tag": AI_DNS_TAG,
            "address": dns_url.replace("https://", "https+local://", 1),
            "domains": domains,
            "skipFallback": True,
        }
        servers[:] = [s for s in servers
                      if not (isinstance(s, dict) and s.get("tag") == AI_DNS_TAG)]
        servers.insert(0, ai_server)  # первым: правило по доменам важнее

    # --- Routing ---
    routing = cfg.setdefault("routing", {})
    rules = routing.setdefault("rules", [])
    rules[:] = [r for r in rules if r.get("ruleTag") != "ai-direct"]
    ai_rule = {
        "type": "field",
        "ruleTag": "ai-direct",
        "domain": domains,
        "outboundTag": direct_tag,
    }
    # В начало, но после служебного правила DNS-входа, если оно есть
    insert_at = 0
    for i, r in enumerate(rules):
        if r.get("inboundTag") and "dns" in str(r.get("outboundTag", "")).lower():
            insert_at = i + 1
    rules.insert(insert_at, ai_rule)
    return cfg


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("profile")
    ap.add_argument("--dns", default=DEFAULT_DNS)
    ap.add_argument("--dns-host", default=DEFAULT_DNS_HOST)
    ap.add_argument("--dns-ip", action="append")
    ap.add_argument("--domain", action="append", help="доп. домен ИИ")
    a = ap.parse_args()

    with open(a.profile, encoding="utf-8") as f:
        cfg = json.load(f)
    ips = a.dns_ip or DEFAULT_DNS_IPS
    doms = DEFAULT_AI_DOMAINS + (a.domain or [])
    json.dump(inject(cfg, a.dns, a.dns_host, ips, doms),
              sys.stdout, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    main()
